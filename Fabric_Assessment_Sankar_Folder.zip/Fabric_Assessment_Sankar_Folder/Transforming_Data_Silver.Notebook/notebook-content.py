# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "81b3d98b-f52c-4b47-8351-06106e129634",
# META       "default_lakehouse_name": "Lakehouse_Sankar",
# META       "default_lakehouse_workspace_id": "f4427070-ec59-47c4-b640-b40f6093848f",
# META       "known_lakehouses": [
# META         {
# META           "id": "81b3d98b-f52c-4b47-8351-06106e129634"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#Read ERP CSV File

df = spark.read.format("csv").option("header","true").load("Files/Sankar_Bronze/erp_data.csv")
# df now is a Spark DataFrame containing CSV data from "Files/Sankar_Bronze/erp_data.csv".
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.write.format("delta").mode("overwrite").save("Tables/ERP_Data_Silver")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Read CRM CSV File

df = spark.read.format("csv").option("header","true").load("Files/Sankar_Bronze/crm_data.csv")
# df now is a Spark DataFrame containing CSV data from "Files/Sankar_Bronze/erp_data.csv".
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.write.format("delta").mode("overwrite").save("Tables/CRM_Data_Silver")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
