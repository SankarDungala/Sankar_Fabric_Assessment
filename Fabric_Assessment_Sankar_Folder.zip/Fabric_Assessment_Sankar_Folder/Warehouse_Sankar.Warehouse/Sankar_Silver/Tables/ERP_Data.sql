CREATE TABLE [Sankar_Silver].[ERP_Data] (

	[product_id] varchar(8000) NULL, 
	[product_name] varchar(8000) NULL, 
	[category] varchar(8000) NULL, 
	[price] varchar(8000) NULL, 
	[stock_quantity] varchar(8000) NULL
);

