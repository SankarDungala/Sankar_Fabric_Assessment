CREATE TABLE [Sankar_Silver].[API_Data] (

	[id] bigint NULL, 
	[name] varchar(8000) NULL, 
	[latitude] varchar(8000) NULL, 
	[longitude] varchar(8000) NULL
);

